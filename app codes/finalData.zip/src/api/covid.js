import axios  from 'axios'

export default axios.create({
    baseURL: 'https://covid19.mohp.gov.np/covid/api/',
    
})

// https://corona.askbhunte.com/api/v1/news

// https://api.openweathermap.org/data/2.5/weather?q=damak,nepal&appid=7c75f3c7c89189edb8cdfebfdc4e36c4

// https://corona.askbhunte.com/api/v1/hospitals
// https://api.openweathermap.org/data/2.5/onecall?lat=26.6687276&lon=87.7000895&appid=7c75f3c7c89189edb8cdfebfdc4e36c4

// https://api.opencagedata.com/geocode/v1/json?q=26.6687276+87.7000895&key=bd321264094b486189c40d86969bba70 
// bd321264094b486189c40d86969bba70